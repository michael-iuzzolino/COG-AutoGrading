#include <iostream>
#include "student_functions_file.cpp"

using namespace std;


int main(void)
{
	// Testcase 1
	calculatePopulation();
	secondsToTime();
	secondsToTime();
	celsiusToFahrenheit();
	celsiusToFahrenheit();
	return 0;
}
